# Model roster

Five ImageNet-pretrained backbones, all loaded through `timm` and wrapped in the shared
`FeatureExtractor` so they expose one contract: image batch in, pooled `(B, feat_dim)` embedding out.

Figures below were measured by instantiating each model at 224x224, not copied from papers.

| Model | timm id | Year | Family | Params (M) | feat_dim | Unfrozen in stage 2 (M) | % of trunk |
|---|---|---|---|---|---|---|---|
| ResNet50 | `resnet50` | 2015 | CNN, residual | 23.51 | 2048 | 14.96 | 63.7% |
| EfficientNet-B0 | `efficientnet_b0` | 2019 | CNN, compound-scaled | 4.01 | 1280 | 3.16 | 78.9% |
| MobileNetV3-Small | `mobilenetv3_small_100` | 2019 | CNN, edge | 1.52 | 1024 | 1.33 | 87.4% |
| DeiT-Small | `deit_small_patch16_224` | 2021 | Vision transformer | 21.67 | 384 | 7.10 | 32.8% |
| ConvNeXt-Tiny | `convnext_tiny` | 2022 | CNN, modern | 27.82 | 768 | 15.47 | 55.6% |

## Which blocks unfreeze

Declared per backbone rather than by a depth percentage, so "unfreeze the top stage" is the same
architectural decision in each case:

| Model | Parameter-name fragments unfrozen |
|---|---|
| ResNet50 | `layer4` |
| EfficientNet-B0 | `blocks.5`, `blocks.6`, `conv_head`, `bn2` |
| ConvNeXt-Tiny | `stages.3`, `norm_pre`, `head.` |
| MobileNetV3-Small | `blocks.4`, `blocks.5`, `conv_head` |
| DeiT-Small | `blocks.8` to `blocks.11`, `norm.` |

Note for the write-up: the same phrase means very different things by parameter count. Unfreezing
the top stage moves 33% of DeiT-Small but 87% of MobileNetV3-Small, because the small CNNs
concentrate their parameters near the head. Any claim about "fine-tuning the last stage" should
carry this table beside it.

## Two implementation details that bit us

1. **`trunk.num_features` is not the embedding width.** MobileNetV3-Small reports 576 but emits
   1024 with `num_classes=0`. The extractor measures the width with a dummy forward instead of
   trusting the attribute; trusting it builds a head of the wrong size and fails at the first batch.
2. **Frozen BatchNorm still moves.** A BN layer with frozen weights keeps updating its running
   mean and variance in `train()` mode, which drifts the frozen part of the trunk while the top is
   being fine-tuned. `freeze_frozen_bn()` puts every fully-frozen BN back into `eval()`.
   Affects ResNet, EfficientNet and MobileNetV3; DeiT uses LayerNorm and is unaffected.

## Normalisation

Each checkpoint keeps its own mean/std and `crop_pct`, read from
`timm.data.resolve_model_data_config`. Forcing one normalisation across all five would handicap
whichever models were not trained under it, and would make the comparison invalid.

## Status against the 13 Nov MoM

The MoM asks for 4-5 models, "two base models, other 2/3 can be new". The roster above is
2015-2022: two sound base models and no recent ones. Selecting the recent models depends on the
literature review, which has not been done.
