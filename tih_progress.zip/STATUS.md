# Work completed — status against the 13 Nov 2026 MoM

Last updated: 14 Nov 2026. Deliverable due 18 Nov.

## Done

| MoM item | Where | Notes |
|---|---|---|
| 1-3. Common/shared feature map, shared backbone | `tih.ipynb` Step 6b | `FeatureExtractor` wraps any timm backbone into one pooled-embedding contract |
| 6. Validation and test accuracy | Steps 7-10 | macro-F1, balanced accuracy, macro P/R, per-class table |
| 8. "Take as it is and check" | Step 8 | full-data supervised baseline |
| 9. Benchmark | Steps 8-9 | five backbones, identical recipe, seed and slice; comparison table and figures |
| Class distribution of training set | Step 2c | produced as a cleaning artefact, not yet tied to accuracy |

Also complete, though not asked for in the MoM: the whole data pipeline — integrity audit,
exact (MD5) and near-duplicate (dHash) removal, stratified 80/10/10 split with a hard leakage
check, augmentation policy, and a CSV audit trail for every rejected image.

## Not done

| MoM item | Why it matters |
|---|---|
| 4, 5, 7. Vary the labelled fraction, 1%-50% | The main deliverable per the 13 Nov 10:53 note. Nothing implemented. The 25% slice in Step 8 is a compute-saving device for ranking backbones, not a label-scarcity experiment — a different axis |
| 10. Literature review, models released in the last year | Not started. Also gates the model roster: the current five are 2015-2022 |
| Model selection: "2/3 can be new" | Unmet until the literature review picks the recent models |

## Open design question, unresolved by the MoM

PlantVillage is 100% labelled, so "check what percentage is labelled" cannot be measured — it has
to be simulated by holding out labels. That leaves a choice the MoM does not settle: is the
unlabelled remainder **discarded** (supervised baseline at 1%, 5%, 10%, 25%, 50%) or **used**
(pseudo-labelling or another semi-supervised method)? The two produce different experiments and
different claims. This needs an answer before the sweep is built.

## Not yet run

No model has been trained. The notebook is written and smoke-tested end to end on a synthetic
fixture, but the dataset has not been through it, so there are no checkpoints, no metrics, no
figures and no benchmark numbers. Every table in the notebook is empty until it runs.

Expected runtime on a T4: roughly 2-3 hours for the five-backbone benchmark, plus about 1.5 hours
for the winner retrained on the full training split.

## Dataset

PlantVillage (updated), Kaggle `tushar5harma/plant-village-dataset-updated`, CC0.
After cleaning: 16 classes, 53,590 train / 6,699 val / 6,699 test.
